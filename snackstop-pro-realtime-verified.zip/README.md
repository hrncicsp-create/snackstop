SnackStop — Realtime Build. See db/schema.sql & db/seed.sql, and set envs in .env.local.
