'use client'
import Header from '@/components/Header'
import BottomNav from '@/components/BottomNav'
import { useCart } from '@/lib/cart'
import { useAuth } from '@/lib/auth'
import { supabase } from '@/lib/supabaseClient'
import { useEffect } from 'react'
export default function Checkout(){
  const { lines, subtotal, delivery, total, clear } = useCart()
  const { user } = useAuth()
  useEffect(()=>{ if(!user){ window.location.href='/login' } },[user])
  async function place(){
    if(!user){ window.location.href='/login'; return }
    try{
      if(!supabase){ alert('Supabase not configured.'); return }
      const { data, error } = await supabase.from('orders').insert({ user_id: user.id, status: 'placed', total, payload: { lines, subtotal, delivery, total, ts: Date.now() } }).select('id').single()
      if(error) throw error
      localStorage.setItem('snackstop_last_order', data.id); clear(); window.location.href = '/tracking'
    }catch(e:any){ alert('Failed to place order: ' + e.message) }
  }
  return (<div className="min-h-screen text-white pb-28"><Header/><main className="max-w-md mx-auto px-4"><div className="card p-4 mt-4">
    <div className="text-lg font-semibold">Checkout</div>
    <div className="mt-2 space-y-1 text-sm"><div className="flex justify-between"><span>Subtotal</span><span>€{subtotal.toFixed(2)}</span></div><div className="flex justify-between"><span>Delivery</span><span>{delivery===0?'Free':`€${delivery.toFixed(2)}`}</span></div><div className="flex justify-between font-semibold"><span>Total</span><span>€{total.toFixed(2)}</span></div></div>
    <button className="btn btn-primary w-full mt-3" onClick={place}>Place Order</button>
  </div></main><BottomNav/></div>)
}
