'use client'
import { useMemo, useState } from 'react'
import Header from '@/components/Header'
import BottomNav from '@/components/BottomNav'
import { ITEMS, type Item } from '@/lib/items'
import { useCart } from '@/lib/cart'
import Modal from '@/components/Modal'
import ProductCard from '@/components/ProductCard'

export default function Home(){
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState<'all'|'savory'|'sweet'|'drinks'|'boxes'>('all')
  const [focus, setFocus] = useState<Item|null>(null)
  const [picked, setPicked] = useState<string[]>([])
  const { add } = useCart()

  const filtered = useMemo(()=> ITEMS.filter(i =>
    (category==='all' || i.category===category) && (query==='' || i.name.toLowerCase().includes(query.toLowerCase()))
  ),[query, category])

  function addWithAddons(item: Item){
    const addons = (item.addons||[]).filter(a=>picked.includes(a.id))
    add(item, addons); setPicked([]); setFocus(null)
  }

  return (
    <div className="min-h-screen text-white pb-28">
      <Header/>
      <main className="max-w-md mx-auto px-4">
        <div className="mt-4 flex items-center gap-2 card px-3 py-2">
          <input placeholder="Search snacks…" value={query} onChange={e=>setQuery(e.target.value)} className="input"/>
        </div>
        <div className="mt-3 grid grid-cols-5 text-center gap-2">
          {['all','savory','sweet','drinks','boxes'].map(c => (
            <button key={c} onClick={()=>setCategory(c as any)} className={`px-2 py-1 rounded-xl border text-sm ${category===c ? 'bg-pink-500/20 border-pink-400/40' : 'bg-white/5 border-white/10'}`}>{c[0].toUpperCase()+c.slice(1)}</button>
          ))}
        </div>
        <div className="mt-4 grid gap-3">
          {(filtered.length?filtered:ITEMS).map(it=> (
            <ProductCard key={it.id} item={it} onAdd={()=>add(it)} onDetails={()=>{ setFocus(it); setPicked([]) }} />
          ))}
        </div>
      </main>
      <BottomNav/>
      <Modal open={!!focus} onClose={()=>setFocus(null)}>
        {focus && (<div>
          <div className="text-lg font-semibold">{focus.name}</div>
          <div className="text-white/70 text-sm">{focus.desc}</div>
          {focus.addons && (<div className="mt-3">
            <div className="text-sm font-medium mb-2">Add-ons</div>
            <div className="grid grid-cols-2 gap-2">
              {focus.addons.map(a => {
                const on = picked.includes(a.id)
                return (
                  <button key={a.id} onClick={()=> setPicked(on? picked.filter(id=>id!==a.id) : [...picked, a.id])}
                    className={`rounded-xl border px-3 py-2 text-left ${on? 'border-lime-400/40 bg-lime-500/10':'border-white/10 bg-white/5'}`}>
                    <div className="text-sm">{a.name}</div>
                    <div className="text-xs text-white/60">+ €{a.price.toFixed(2)}</div>
                  </button>
                )
              })}
            </div>
          </div>)}
          <div className="mt-4 grid grid-cols-2 gap-2">
            <button className="btn" onClick={()=>setFocus(null)}>Cancel</button>
            <button className="btn btn-primary" onClick={()=>addWithAddons(focus)}>Add to Cart</button>
          </div>
        </div>)}
      </Modal>
    </div>
  )
}
