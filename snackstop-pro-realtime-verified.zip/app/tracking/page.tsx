'use client'
import { useEffect, useState } from 'react'
import Header from '@/components/Header'
import BottomNav from '@/components/BottomNav'
import { supabase } from '@/lib/supabaseClient'
type Order = { id: string; status: string; total: number; payload: any; created_at: string }
export default function Tracking(){
  const [order, setOrder] = useState<Order | null>(null)
  const [progress, setProgress] = useState(0)
  useEffect(()=>{
    const id = localStorage.getItem('snackstop_last_order')
    if(!id || !supabase) return
    const init = async ()=>{ const { data } = await supabase.from('orders').select('*').eq('id', id).maybeSingle(); if(data) setOrder(data as any) }
    init()
    const ch = supabase.channel('orders-tracking').on('postgres_changes',{event:'*',schema:'public',table:'orders',filter:`id=eq.${id}`},(payload)=> setOrder(payload.new as any)).subscribe()
    return ()=>{ supabase.removeChannel(ch) }
  },[])
  useEffect(()=>{ const map: Record<string, number> = { placed:10, preparing:40, dispatched:70, delivered:100 }; if(order?.status) setProgress(map[order.status] ?? progress) },[order?.status])
  return (<div className="min-h-screen text-white pb-28"><Header/><main className="max-w-md mx-auto px-4"><div className="card p-4 mt-4">
    <div className="text-lg font-semibold">En route</div>
    <div className="text-white/70 text-sm">{order ? <>Order <span className="text-white/80">{order.id.slice(0,8)}</span> — <span className="font-semibold">{order.status}</span></> : 'Waiting for order...'}</div>
    <div className="mt-3 h-2 bg-white/10 rounded-full overflow-hidden"><div className="h-full bg-white/80" style={{width: progress+'%'}}/></div><div className="text-xs text-white/60 mt-2">Progress: {progress}%</div>
  </div></main><BottomNav/></div>)
}
