'use client'
import { useState } from 'react'
import Header from '@/components/Header'
import BottomNav from '@/components/BottomNav'
import { supabase } from '@/lib/supabaseClient'
export default function Login(){
  const [email, setEmail] = useState(''); const [sent, setSent] = useState(false); const [error, setError] = useState<string|null>(null)
  async function send(){ setError(null); if(!supabase){ setError('Supabase not configured'); return }
    const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: (typeof window !== 'undefined' ? window.location.origin : '') + '/account' } }); if(error){ setError(error.message) } else setSent(true)
  }
  return (<div className="min-h-screen text-white pb-28"><Header/><main className="max-w-md mx-auto px-4"><div className="card p-4 mt-4">
    <div className="text-lg font-semibold">Login</div><div className="text-white/70 text-sm">Magic link sign-in</div>
    <div className="mt-3 flex items-center gap-2 card px-3 py-2"><input placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)} className="input"/></div>
    <button className="btn btn-primary w-full mt-3" onClick={send}>Send magic link</button>
    {sent && <div className="text-emerald-400 mt-2 text-sm">Check your email for the link.</div>}{error && <div className="text-red-400 mt-2 text-sm">{error}</div>}
  </div></main><BottomNav/></div>)
}
