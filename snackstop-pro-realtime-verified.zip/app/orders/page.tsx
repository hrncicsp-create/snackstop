'use client'
import Header from '@/components/Header'
import BottomNav from '@/components/BottomNav'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabaseClient'
import { useAuth } from '@/lib/auth'
type Order = { id: string; status: string; total: number; created_at: string }
export default function Orders(){
  const { user } = useAuth(); const [orders, setOrders] = useState<Order[]>([])
  useEffect(()=>{
    async function load(){ if(!supabase || !user){ setOrders([]); return }
      const { data } = await supabase.from('orders').select('id,status,total,created_at').eq('user_id', user.id).order('created_at', { ascending: false }); setOrders(data || [])
    } load()
    if(!supabase || !user) return
    const ch = supabase.channel('orders-feed').on('postgres_changes', { event:'*', schema:'public', table:'orders', filter:`user_id=eq.${user?.id}` }, ()=>load()).subscribe()
    return ()=>{ supabase.removeChannel(ch) }
  },[user?.id])
  return (<div className="min-h-screen text-white pb-28"><Header/><main className="max-w-md mx-auto px-4"><div className="card p-4 mt-4">
    <div className="text-lg font-semibold">Your Orders</div>
    <div className="mt-3 space-y-2">{orders.length===0 && <div className="text-white/60">No orders yet.</div>}
    {orders.map(o => (<div key={o.id} className="flex items-center justify-between bg-white/5 border border-white/10 rounded-xl p-3">
      <div><div className="font-medium">#{o.id.slice(0,8)}</div><div className="text-xs text-white/60">{new Date(o.created_at).toLocaleString()}</div></div>
      <div className="text-right"><div className="text-sm">{o.status}</div><div className="text-xs text-white/60">€{Number(o.total).toFixed(2)}</div></div>
    </div>))}</div>
  </div></main><BottomNav/></div>)
}
